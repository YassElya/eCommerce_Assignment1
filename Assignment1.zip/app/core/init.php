<?php
	require("app/core/autoload.php");
