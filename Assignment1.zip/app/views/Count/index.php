<?php
namespace app\views;

	echo "<p>Copyright &copy; 1999-" . date("Y") . " Google Chrome</p>";

	