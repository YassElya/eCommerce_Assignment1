<?php
$handle = fopen("app/resources/counter.txt", "r"); 
if(!$handle) { 
    echo "could not open the file"; 
} else { 
    $counter =(int )fread($handle,20);
        fclose($handle); 
        $counter++; 
        echo"Number of visits on this page so far: ". $counter . " visits" ; 
    $handle = fopen("counter.txt", "w" ); 

    fwrite($handle,$counter);
    fclose ($handle);
}
