# eCommerce_Assignment1
This our assignment 1 (Yassine El Yamani, Amirreza Saeidi & Damiano Visalli)